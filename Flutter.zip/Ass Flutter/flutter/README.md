Name: Deeqo abdikadir garad
ID:C119753
Class: CA192
this is flutter assignment